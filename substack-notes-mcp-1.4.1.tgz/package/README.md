# Substack Notes MCP

Create, schedule, manage, and fetch Substack notes from any AI assistant — Claude Desktop, Claude Code, or Cursor.

Built by [Jenny Ouyang](https://buildtolaunch.substack.com).

## Setup

### 1. Get your API token

Go to [quickviralnotes.com/settings](https://quickviralnotes.com/settings) and generate an MCP API token.

### 2. Connect your AI assistant

**Claude Desktop** — add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "substack-notes": {
      "command": "npx",
      "args": ["-y", "substack-notes-mcp", "--token", "YOUR_TOKEN"]
    }
  }
}
```

**Claude Code** — run:

```bash
claude mcp add -s user substack-notes -- npx -y substack-notes-mcp --token YOUR_TOKEN
```

The `-s user` flag installs it globally so it's available in all your projects.

**Cursor** — add to your MCP settings:

```json
{
  "mcpServers": {
    "substack-notes": {
      "command": "npx",
      "args": ["-y", "substack-notes-mcp", "--token", "YOUR_TOKEN"]
    }
  }
}
```

Or connect directly via Streamable HTTP:

- **URL:** `https://qvn-mcp.vercel.app/mcp`
- **Header:** `Authorization: Bearer YOUR_TOKEN`

## Available Tools

| Tool | Description |
|------|-------------|
| `get_notes_dashboard` | View published and planned notes with category distributions |
| `get_published_notes` | List your recently published notes |
| `get_planned_notes` | View planned notes and open scheduling slots |
| `get_unscheduled_notes` | Get notes ready to be scheduled |
| `create_note` | Create a new note with HTML content and category |
| `schedule_note` | Set or update the planned date for a note |
| `unschedule_note` | Remove the planned date from a note |
| `mark_note_published` | Mark a note as published with optional Substack URL |
| `fetch_substack_notes` | Fetch published notes from any Substack author or publication (public, no cookies needed) |
| `fetch_note_comments` | Fetch all comments and restacks for a specific note (public, no cookies needed) |
| `get_hook_templates` | Browse 167 proven hook templates for crafting viral note openings |
| `add_hook_template` | Add a new hook template to the library (admin-only) |

## Requirements

- Node.js 18+
- A Quick Viral Notes account (free accounts can use read-only tools; creating and scheduling notes requires a subscription)

## License

MIT
